﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace BlackHoleAvalonia.ViewModels;

public class ViewModelBase : ObservableObject
{
}
