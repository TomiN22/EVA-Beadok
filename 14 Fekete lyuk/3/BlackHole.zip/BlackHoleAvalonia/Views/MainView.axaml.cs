﻿using Avalonia.Controls;

namespace BlackHoleAvalonia.Views;

public partial class MainView : UserControl
{
    public MainView()
    {
        InitializeComponent();
    }
}
