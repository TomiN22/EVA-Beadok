﻿using Avalonia.Controls;

namespace BlackHoleAvalonia.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
